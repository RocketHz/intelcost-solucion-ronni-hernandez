# suplosBackEnd
Prueba suplos desarrollador backend

a. PHP Versión 7 o superior.
b. Versión base de datos (Mysql).

Se debe configurar los puertos de la base de datos local, ya que mi puerto local es 8080, tener en cuenta antes de evaluar :)

El puerto en el que corro MySQL es el puerto 3306
Muchas Gracias...