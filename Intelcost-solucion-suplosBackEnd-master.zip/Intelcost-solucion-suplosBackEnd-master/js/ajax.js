const xhttp2 = new XMLHttpRequest();
var fs_data = [];

xhttp2.open("POST", "../php/data.php", true);

xhttp2.onreadystatechange = function () {
    if (this.readyState == 4 && this.status == 200) {
        var sD = JSON.parse(this.responseText);

        for (let i = data.length - 1; i >= 0; i--) {
            for (let j = sD.length - 1; j >= 0; j--) {
                if (data[i].Id == sD[j].item_id) {
                    fs_data.push(data[i]);
                    break;
                }
            }
        }

        if (fs_data.length != 0) {
            for (let i = fs_data.length - 1; i >= 0; i--) {
                document.querySelector("#show_save_data").innerHTML +=
                    "<div class='itemMostrado' id='" +
                    fs_data[i].Id +
                    "'><img src='/img/home.jpg'><span>Dirección :" +
                    fs_data[i].Direccion +
                    "</span><br><span>Ciudad: " +
                    fs_data[i].Ciudad +
                    "</span><br><span>Telefono: " +
                    fs_data[i].Telefono +
                    "</span><br><span>Codigo postal: " +
                    fs_data[i].Codigo_Postal +
                    "</span><br><span>Tipo: " +
                    fs_data[i].Tipo +
                    "</span><br><span>Precio: " +
                    fs_data[i].Precio +
                    "</span><br></div><div class='divider mt-10'></div>";
            }
        }
    } else {
        alert("No se han podido obtener los datos del servidor.");
    }
};

xhttp2.send();