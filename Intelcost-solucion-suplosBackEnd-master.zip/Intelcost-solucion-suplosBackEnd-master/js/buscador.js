document.querySelector("#submitButton").addEventListener("click", function (e) {
    e.preventDefault();
    document.querySelector("#finalData").innerHTML =
        "<h5>Resultados de la búsqueda:</h5>";
    var fD = [];

    var City = document.querySelector("#selectCiudad").value;
    var LivingPlaceType = document.querySelector("#selectTipo").value;

    if (City != 0 || LivingPlaceType != 0) {
        for (let i = data.length - 1; i >= 0; i--) {
            if (City != 0 && LivingPlaceType != 0) {
                if (data[i].City == City && data[i].Tipo == LivingPlaceType) {
                    fD.push(data[i]);
                }
            }

            if (City != 0 && LivingPlaceType == 0) {
                if (data[i].City == City) {
                    fD.push(data[i]);
                }
            } else if (City == 0 && LivingPlaceType != 0) {
                if (data[i].Tipo == LivingPlaceType) {
                    fD.push(data[i]);
                }
            }
        }
    } else {
        alert(
            "Debe seleccionar una Ciudad o un tipo de vivienda"
        );
    }
    document.querySelector("#finalData").innerHTML =
        "<h5>Resultados de la búsqueda: " + fD.length + "</h5>";

    for (let i = fD.length - 1; i >= 0; i--) {
        document.querySelector("#finalData").innerHTML +=
            "<div class='itemMostrado' id='" +
            fD[i].Id +
            "'><img src='/img/home.jpg'><span>Dirección :" +
            fD[i].Direccion +
            "</span><br><span>Ciudad: " +
            fD[i].Ciudad +
            "</span><br><span>Telefono: " +
            fD[i].Telefono +
            "</span><br><span>Codigo postal: " +
            fD[i].Codigo_Postal +
            "</span><br><span>Tipo: " +
            fD[i].Tipo +
            "</span><br><span>Precio: " +
            fD[i].Precio +
            "</span><br><form action='/php/save.php' method='POST'><input type='hidden' value='" +
            fD[i].Id +
            "' name='id'><button id='button" +
            fD[i].Id +
            "' class='save_button'>Guardar</button></form></div><div class='divider mt-10'></div>";
    }
});