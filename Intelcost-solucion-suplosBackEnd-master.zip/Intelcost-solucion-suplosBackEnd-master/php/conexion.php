<?php 

	try
	{
		$conexion = new pdo('mysql:host=localhost:8080;dbname=intelcost-bienes','root','');
	}
	catch (Exception $e)
	{
		die('Error: '.$e->getMessage());
	}

?>	
