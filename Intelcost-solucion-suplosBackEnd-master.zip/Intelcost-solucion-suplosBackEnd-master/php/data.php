<?php
	require('./conexion.php');
	$statement = $conexion->prepare('SELECT * FROM saved_data');
	$statement -> execute();
	$response = $statement->fetchAll();
	echo json_encode($response);


?>
