<?php 

	require('./conexion.php');
	$statement = $conexion->prepare('INSERT INTO saved_data VALUES(:id)');
	$statement->execute(array(':id' => $_POST['id']));

	header('location: ../index.html');




?>
